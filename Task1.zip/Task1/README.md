REFER images and folder 
used application :MySQL Workbench
